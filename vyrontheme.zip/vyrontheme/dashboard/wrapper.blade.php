@verbatim
<script>
(function () {
  if (window.__vyHeader) return;
  window.__vyHeader = true;

  // Ubah teks status di sini kalau mau
  var STATUS = {
    running:  { cls: 'vy-on',   text: 'Online' },
    offline:  { cls: 'vy-off',  text: '\u26A0 Offline \u00B7 tekan Start' },
    starting: { cls: 'vy-warn', text: '\u26A0 Sedang dinyalakan\u2026' },
    stopping: { cls: 'vy-warn', text: '\u26A0 Sedang dimatikan\u2026' }
  };
  var SUSPENDED = { cls: 'vy-off', text: '\u26A0 Server ditangguhkan' };
  var LOADING = { cls: 'vy-warn', text: 'Memuat\u2026' };

  var ICON = '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 3 7.5 12 12l9-4.5z"/><path d="M3 12l9 4.5 9-4.5"/><path d="M3 16.5 12 21l9-4.5"/></svg>';
  var cur = { id: null, name: '', state: null, suspended: false, last: 0, busy: false };

  function sid() {
    var m = location.pathname.match(/^\/server\/([^\/?#]+)/);
    return m ? m[1] : null;
  }

  function get(path) {
    return fetch('/api/client/servers/' + path, {
      credentials: 'same-origin',
      headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
    }).then(function (r) {
      if (!r.ok) throw new Error(r.status);
      return r.json();
    });
  }

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    return e;
  }

  function build(id) {
    var h = el('div');
    h.id = 'vy-server-header';
    var back = el('a', 'vy-back', '\u2039');
    back.href = '/';
    back.setAttribute('aria-label', 'Kembali');
    var icon = el('div', 'vy-icon');
    icon.innerHTML = ICON;
    var meta = el('div', 'vy-meta');
    meta.appendChild(el('div', 'vy-name', '\u2026'));
    meta.appendChild(el('div', 'vy-status vy-warn', 'Memuat\u2026'));
    var more = el('a', 'vy-more', '\u22EE');
    more.href = '/server/' + id + '/settings';
    more.setAttribute('aria-label', 'Pengaturan');
    h.appendChild(back); h.appendChild(icon); h.appendChild(meta); h.appendChild(more);
    return h;
  }

  function paint(h) {
    if (!h) return;
    var n = h.querySelector('.vy-name');
    var s = h.querySelector('.vy-status');
    if (n) n.textContent = cur.name || '\u2026';
    var st = cur.suspended ? SUSPENDED : (STATUS[cur.state] || LOADING);
    if (s) { s.className = 'vy-status ' + st.cls; s.textContent = st.text; }
  }

  function refresh() {
    var now = Date.now();
    if (cur.busy || now - cur.last < 5000) { paint(document.getElementById('vy-server-header')); return; }
    cur.busy = true; cur.last = now;
    var id = cur.id, jobs = [];
    if (!cur.name) {
      jobs.push(get(id).then(function (j) {
        cur.name = j.attributes.name || '';
        cur.suspended = !!j.attributes.is_suspended;
      }));
    }
    jobs.push(get(id + '/resources').then(function (j) {
      cur.state = j.attributes.current_state;
    }));
    Promise.all(jobs).catch(function () {}).then(function () {
      cur.busy = false;
      paint(document.getElementById('vy-server-header'));
    });
  }

  function tick() {
    try {
      var id = sid();
      var old = document.getElementById('vy-server-header');
      if (!id) { if (old) old.remove(); cur.id = null; return; }
      if (cur.id !== id) {
        cur = { id: id, name: '', state: null, suspended: false, last: 0, busy: false };
        if (old) { old.remove(); old = null; }
      }
      if (!old) {
        var link = document.querySelector('a[href="/server/' + id + '/files"]');
        if (!link) return;
        var bar = link.parentElement;
        for (var i = 0; i < 3 && bar.parentElement && bar.parentElement.children.length === 1; i++) {
          bar = bar.parentElement;
        }
        bar.classList.add('vy-tabbar');
        bar.parentNode.insertBefore(build(id), bar);
      }
      refresh();
    } catch (e) {}
  }

  setInterval(tick, 1000);
  tick();
})();
</script>
@endverbatim
